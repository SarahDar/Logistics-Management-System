INSERT INTO Warehouse(warehouseID, city)
VALUES ("W01", "Lahore");

INSERT INTO Warehouse(warehouseID, city)
VALUES ("W02", "Islamabad");

INSERT INTO Warehouse(warehouseID, city)
VALUES ("W03", "Multan");

INSERT INTO Warehouse(warehouseID, city)
VALUES ("W04", "Karachi");
