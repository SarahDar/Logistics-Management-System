DELETE FROM Client WHERE phoneNumber = "03014884962";
INSERT INTO Client(phoneNumber, clientAddress, city)
VALUES ("03014884962", "631/Z Block/Phase 3/DHA", "Lahore");

DELETE FROM Client WHERE phoneNumber = "03034444631";
INSERT INTO Client(phoneNumber, clientAddress, city)
VALUES ("03034444631", "631/Z Block/Phase 3/DHA", "Karachi");


DELETE FROM Client WHERE phoneNumber = "03008452847";
INSERT INTO Client(phoneNumber, clientAddress, city)
VALUES ("03008452847", "631/Z Block/Phase 3/DHA", "Islamabad");

DELETE FROM Client WHERE phoneNumber = "034654522251";
INSERT INTO Client(phoneNumber, clientAddress, city)
VALUES ("03464522251", "631/Z Block/Phase 3/DHA", "Mutan");