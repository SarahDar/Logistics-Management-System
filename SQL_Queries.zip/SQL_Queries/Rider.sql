DELETE FROM Rider WHERE riderID= "R01";
INSERT INTO Rider(riderID, riderName, warehouseID, phoneNumber)
VALUES ("R01", "Bashir", "W03", "0300123456");

DELETE FROM Rider WHERE riderID= "R02";
INSERT INTO Rider(riderID, riderName, warehouseID, phoneNumber)
VALUES ("R02", "Mushtaq", "W01", "0300122356");

DELETE FROM Rider WHERE riderID= "R03";
INSERT INTO Rider(riderID, riderName, warehouseID, phoneNumber)
VALUES ("R03", "Abd", "W01","0300124342");
