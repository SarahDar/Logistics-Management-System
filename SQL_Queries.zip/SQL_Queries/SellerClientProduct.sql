INSERT INTO SellerProduct(sellerID, productID, weightPrice, deliveryPrice, sellerPrice) 
VALUES ("S01", "P01", 100, 100, 1000);

INSERT INTO ClientProduct(clientPhoneNumber, productID, deliveryAddress)
VALUES ("03014884962", "P01", "631/Z Block/Phase 3/DHA");

